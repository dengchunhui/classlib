var lang={
    name:"名称",
    title:"标题",
    content:"这是内容",
};