var lang={
    name:"en name",
    title:"en title",
    content:"this is content",
};